function myFunction() {
  window.open("https://www.wolframcloud.com/obj/56e981e3-e57c-4f91-94d9-98a16838fc65");
}